//
//  ViewController.swift
//  chatApp2
//
//  Created by David Rothschild on 1/19/16.
//  Copyright © 2016 Dave Rothschild. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var socket: SocketIOClient?
    // let socket = SocketIOClient(socketURL: "http://192.168.1.233:6789")
    
    @IBOutlet weak var urlLabel: UITextField!
    
    @IBOutlet weak var urlSendText: UITextField!
    
    
    @IBAction func sendButtonPressed(sender: UIButton) {
    }
    
    
    @IBAction func connectButtonPressed(sender: UIButton) {
        socket = SocketIOClient(socketURL: urlLabel.text!)
        socket!.connect()
        socket!.on("connect") { data, ack in
            print("iOS::WE ARE USING SOCKETS!")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        socket.connect()
//        socket.on("connect") { data, ack in
//            print("iOS::WE ARE USING SOCKETS!")
//        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

